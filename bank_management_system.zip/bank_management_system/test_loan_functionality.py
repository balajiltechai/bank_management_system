"""
Enhanced Test script for Bank Management System with Loan functionality
"""

import requests
import json
import time

# Configuration
BASE_URL = "http://localhost:5000"
TEST_USER_DATA = {
    "name": "Jane Smith",
    "username": "janesmith",
    "password": "password123",
    "confirm_password": "password123",
    "address": "456 Oak Avenue, Suite 12",
    "state": "New York",
    "country": "United States",
    "email": "jane.smith@email.com",
    "pan": "FGHIJ5678K",
    "contact_no": "+1-555-987-6543",
    "dob": "1985-08-20",
    "account_type": "Current"
}

TEST_LOAN_DATA = {
    "loan_type": "Personal Loan",
    "loan_amount": "500000",
    "application_date": "2025-07-29",
    "rate_of_interest": "12.0",
    "duration_months": "60"
}

def test_loan_application_flow():
    """Test complete loan application flow"""
    print("Testing loan application flow...")
    
    session = requests.Session()
    
    try:
        # Step 1: Register a test user
        print("  1. Registering test user...")
        response = session.post(f"{BASE_URL}/register", data=TEST_USER_DATA)
        if response.status_code == 200:
            print("  ✓ User registration successful")
        else:
            print(f"  ✗ User registration failed: {response.status_code}")
            return False
        
        # Step 2: Login
        print("  2. Logging in...")
        login_data = {
            "username": TEST_USER_DATA["username"],
            "password": TEST_USER_DATA["password"]
        }
        response = session.post(f"{BASE_URL}/login", data=login_data)
        if response.status_code == 200 and "dashboard" in response.url.lower():
            print("  ✓ Login successful")
        else:
            print(f"  ✗ Login failed: {response.status_code}")
            return False
        
        # Step 3: Access loan application page
        print("  3. Accessing loan application page...")
        response = session.get(f"{BASE_URL}/apply_loan")
        if response.status_code == 200:
            print("  ✓ Loan application page accessible")
        else:
            print(f"  ✗ Cannot access loan application page: {response.status_code}")
            return False
        
        # Step 4: Submit loan application
        print("  4. Submitting loan application...")
        response = session.post(f"{BASE_URL}/apply_loan", data=TEST_LOAN_DATA)
        if response.status_code == 200:
            print("  ✓ Loan application submitted")
        else:
            print(f"  ✗ Loan application failed: {response.status_code}")
            return False
        
        # Step 5: View loans page
        print("  5. Accessing view loans page...")
        response = session.get(f"{BASE_URL}/view_loans")
        if response.status_code == 200:
            print("  ✓ View loans page accessible")
            if "Personal Loan" in response.text:
                print("  ✓ Loan application appears in the list")
            else:
                print("  ⚠ Loan application may not be saved properly")
        else:
            print(f"  ✗ Cannot access view loans page: {response.status_code}")
            return False
        
        print("  ✓ Loan application flow test completed successfully!")
        return True
        
    except Exception as e:
        print(f"  ✗ Error in loan application flow: {e}")
        return False

def test_loan_pages_accessibility():
    """Test accessibility of all loan-related pages"""
    print("Testing loan pages accessibility...")
    
    loan_pages = [
        ("/apply_loan", "Loan Application page"),
        ("/view_loans", "View Loans page"),
    ]
    
    for path, description in loan_pages:
        try:
            response = requests.get(f"{BASE_URL}{path}")
            # These pages require login, so 302 redirect is expected
            if response.status_code in [200, 302]:
                print(f"  ✓ {description} responding correctly")
            else:
                print(f"  ⚠ {description} returned status {response.status_code}")
        except Exception as e:
            print(f"  ✗ Error accessing {description}: {e}")

def test_loan_validation():
    """Test loan application validation"""
    print("Testing loan application validation...")
    
    session = requests.Session()
    
    # First, need to login
    try:
        login_data = {
            "username": TEST_USER_DATA["username"],
            "password": TEST_USER_DATA["password"]
        }
        session.post(f"{BASE_URL}/login", data=login_data)
        
        # Test invalid loan amounts
        invalid_loan_data = TEST_LOAN_DATA.copy()
        invalid_loan_data["loan_amount"] = "-1000"
        
        response = session.post(f"{BASE_URL}/apply_loan", data=invalid_loan_data)
        if "greater than zero" in response.text:
            print("  ✓ Negative loan amount validation working")
        else:
            print("  ⚠ Negative loan amount validation may not be working")
        
        # Test invalid interest rate
        invalid_loan_data = TEST_LOAN_DATA.copy()
        invalid_loan_data["rate_of_interest"] = "60"
        
        response = session.post(f"{BASE_URL}/apply_loan", data=invalid_loan_data)
        if "between 0% and 50%" in response.text:
            print("  ✓ Interest rate validation working")
        else:
            print("  ⚠ Interest rate validation may not be working")
        
        print("  ✓ Loan validation tests completed")
        
    except Exception as e:
        print(f"  ✗ Error in loan validation testing: {e}")

def test_database_integration():
    """Test if loan data is properly stored in database"""
    print("Testing database integration...")
    
    session = requests.Session()
    
    try:
        # Login first
        login_data = {
            "username": TEST_USER_DATA["username"],
            "password": TEST_USER_DATA["password"]
        }
        session.post(f"{BASE_URL}/login", data=login_data)
        
        # Submit a unique loan application
        unique_loan_data = TEST_LOAN_DATA.copy()
        unique_loan_data["loan_type"] = "Home Loan"
        unique_loan_data["loan_amount"] = "2500000"
        
        session.post(f"{BASE_URL}/apply_loan", data=unique_loan_data)
        
        # Check if it appears in view loans
        response = session.get(f"{BASE_URL}/view_loans")
        if "Home Loan" in response.text and "2,500,000" in response.text:
            print("  ✓ Loan data properly stored and retrieved from database")
        else:
            print("  ⚠ Loan data may not be properly stored in database")
        
    except Exception as e:
        print(f"  ✗ Error in database integration test: {e}")

def main():
    """Main test function"""
    print("=" * 60)
    print("Bank Management System - Enhanced Test Suite with Loans")
    print("=" * 60)
    
    print("\nWaiting for application to start...")
    time.sleep(2)
    
    # Test basic application structure
    print("\n1. Testing basic application structure...")
    try:
        response = requests.get(BASE_URL)
        if response.status_code == 200:
            print("  ✓ Application is running")
        else:
            print(f"  ✗ Application not responding properly: {response.status_code}")
            return
    except requests.exceptions.ConnectionError:
        print("  ✗ Cannot connect to the application. Make sure it's running on localhost:5000")
        return
    
    # Test loan pages accessibility
    print("\n2. Testing loan pages accessibility...")
    test_loan_pages_accessibility()
    
    # Test complete loan application flow
    print("\n3. Testing complete loan application flow...")
    test_loan_application_flow()
    
    # Test loan validation
    print("\n4. Testing loan validation...")
    test_loan_validation()
    
    # Test database integration
    print("\n5. Testing database integration...")
    test_database_integration()
    
    print("\n" + "=" * 60)
    print("Enhanced Test Suite Completed!")
    print("=" * 60)
    print("\nLoan Management Features to Test Manually:")
    print("1. Open http://localhost:5000 and register/login")
    print("2. Navigate to 'Apply for Loan' from dashboard or navigation menu")
    print("3. Fill out the loan application form with different loan types")
    print("4. Test the EMI calculator functionality")
    print("5. Submit the application and verify it appears in 'My Loans'")
    print("6. Click on loan details to view comprehensive loan information")
    print("7. Test the loan summary statistics on dashboard")
    print("\nNew Features Implemented:")
    print("✓ Loan Application with comprehensive form")
    print("✓ EMI calculation and preview")
    print("✓ Loan listing and management")
    print("✓ Detailed loan view with EMI schedule")
    print("✓ Dashboard integration with loan statistics")
    print("✓ Navigation menu updates")
    print("✓ Form validation and error handling")

if __name__ == "__main__":
    main()
