from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev_secret_key_change_in_production')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///bank_management.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Customer Model
class Customer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    address = db.Column(db.Text, nullable=False)
    state = db.Column(db.String(50), nullable=False)
    country = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    pan = db.Column(db.String(10), unique=True, nullable=False)
    contact_no = db.Column(db.String(15), nullable=False)
    dob = db.Column(db.Date, nullable=False)
    account_type = db.Column(db.String(20), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship with loans
    loans = db.relationship('Loan', backref='customer', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<Customer {self.username}>'

# Loan Model
class Loan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    loan_type = db.Column(db.String(50), nullable=False)
    loan_amount = db.Column(db.Float, nullable=False)
    application_date = db.Column(db.Date, nullable=False, default=datetime.utcnow().date)
    rate_of_interest = db.Column(db.Float, nullable=False)
    duration_months = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(20), default='Pending')  # Pending, Approved, Rejected
    monthly_emi = db.Column(db.Float)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def calculate_emi(self):
        """Calculate monthly EMI based on loan amount, rate and duration"""
        principal = self.loan_amount
        rate = self.rate_of_interest / 100 / 12  # Monthly interest rate
        n = self.duration_months
        
        if rate == 0:
            emi = principal / n
        else:
            emi = (principal * rate * ((1 + rate) ** n)) / (((1 + rate) ** n) - 1)
        
        self.monthly_emi = round(emi, 2)
        return self.monthly_emi
    
    def __repr__(self):
        return f'<Loan {self.loan_type} - {self.customer.username}>'

# Routes
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        # Get form data
        name = request.form['name']
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        address = request.form['address']
        state = request.form['state']
        country = request.form['country']
        email = request.form['email']
        pan = request.form['pan']
        contact_no = request.form['contact_no']
        dob_str = request.form['dob']
        account_type = request.form['account_type']
        
        # Validation
        if password != confirm_password:
            flash('Passwords do not match!', 'error')
            return render_template('register.html')
        
        # Check if username or email already exists
        if Customer.query.filter_by(username=username).first():
            flash('Username already exists!', 'error')
            return render_template('register.html')
        
        if Customer.query.filter_by(email=email).first():
            flash('Email already registered!', 'error')
            return render_template('register.html')
        
        if Customer.query.filter_by(pan=pan).first():
            flash('PAN already registered!', 'error')
            return render_template('register.html')
        
        try:
            # Convert date string to date object
            dob = datetime.strptime(dob_str, '%Y-%m-%d').date()
            
            # Create new customer
            customer = Customer(
                name=name,
                username=username,
                address=address,
                state=state,
                country=country,
                email=email,
                pan=pan.upper(),
                contact_no=contact_no,
                dob=dob,
                account_type=account_type
            )
            customer.set_password(password)
            
            # Save to database
            db.session.add(customer)
            db.session.commit()
            
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
            
        except ValueError:
            flash('Invalid date format!', 'error')
            return render_template('register.html')
        except Exception as e:
            db.session.rollback()
            flash('Registration failed! Please try again.', 'error')
            return render_template('register.html')
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        customer = Customer.query.filter_by(username=username).first()
        
        if customer and customer.check_password(password):
            session['user_id'] = customer.id
            session['username'] = customer.username
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password!', 'error')
    
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash('Please login to access dashboard.', 'error')
        return redirect(url_for('login'))
    
    customer = Customer.query.get(session['user_id'])
    return render_template('dashboard.html', customer=customer)

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        flash('Please login to access profile.', 'error')
        return redirect(url_for('login'))
    
    customer = Customer.query.get(session['user_id'])
    return render_template('profile.html', customer=customer)

@app.route('/apply_loan', methods=['GET', 'POST'])
def apply_loan():
    if 'user_id' not in session:
        flash('Please login to apply for a loan.', 'error')
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        try:
            # Get form data
            loan_type = request.form['loan_type']
            loan_amount = float(request.form['loan_amount'])
            application_date = datetime.strptime(request.form['application_date'], '%Y-%m-%d').date()
            rate_of_interest = float(request.form['rate_of_interest'])
            duration_months = int(request.form['duration_months'])
            
            # Validation
            if loan_amount <= 0:
                flash('Loan amount must be greater than zero!', 'error')
                today = datetime.now().strftime('%Y-%m-%d')
                return render_template('apply_loan.html', today=today)
            
            if rate_of_interest < 0 or rate_of_interest > 50:
                flash('Rate of interest must be between 0% and 50%!', 'error')
                today = datetime.now().strftime('%Y-%m-%d')
                return render_template('apply_loan.html', today=today)
            
            if duration_months <= 0 or duration_months > 360:
                flash('Duration must be between 1 and 360 months!', 'error')
                today = datetime.now().strftime('%Y-%m-%d')
                return render_template('apply_loan.html', today=today)
            
            # Create new loan application
            loan = Loan(
                loan_type=loan_type,
                loan_amount=loan_amount,
                application_date=application_date,
                rate_of_interest=rate_of_interest,
                duration_months=duration_months,
                customer_id=session['user_id']
            )
            
            # Calculate EMI
            loan.calculate_emi()
            
            # Save to database
            db.session.add(loan)
            db.session.commit()
            
            flash(f'Loan application submitted successfully! Your monthly EMI will be ₹{loan.monthly_emi:,.2f}', 'success')
            return redirect(url_for('view_loans'))
            
        except ValueError:
            flash('Please enter valid numeric values!', 'error')
            today = datetime.now().strftime('%Y-%m-%d')
            return render_template('apply_loan.html', today=today)
        except Exception as e:
            db.session.rollback()
            flash('Loan application failed! Please try again.', 'error')
            today = datetime.now().strftime('%Y-%m-%d')
            return render_template('apply_loan.html', today=today)
    
    # Pass today's date to template
    today = datetime.now().strftime('%Y-%m-%d')
    return render_template('apply_loan.html', today=today)

@app.route('/view_loans')
def view_loans():
    if 'user_id' not in session:
        flash('Please login to view your loans.', 'error')
        return redirect(url_for('login'))
    
    customer = Customer.query.get(session['user_id'])
    loans = Loan.query.filter_by(customer_id=session['user_id']).order_by(Loan.created_at.desc()).all()
    
    return render_template('view_loans.html', customer=customer, loans=loans)

@app.route('/loan_details/<int:loan_id>')
def loan_details(loan_id):
    if 'user_id' not in session:
        flash('Please login to view loan details.', 'error')
        return redirect(url_for('login'))
    
    loan = Loan.query.filter_by(id=loan_id, customer_id=session['user_id']).first()
    if not loan:
        flash('Loan not found or access denied!', 'error')
        return redirect(url_for('view_loans'))
    
    return render_template('loan_details.html', loan=loan)

@app.route('/update_account', methods=['GET', 'POST'])
def update_account():
    if 'user_id' not in session:
        flash('Please login to update your account details.', 'error')
        return redirect(url_for('login'))
    
    customer = Customer.query.get(session['user_id'])
    if not customer:
        flash('Customer not found!', 'error')
        return redirect(url_for('logout'))
    
    if request.method == 'POST':
        try:
            # Get form data
            name = request.form['name'].strip()
            email = request.form['email'].strip().lower()
            address = request.form['address'].strip()
            state = request.form['state'].strip()
            country = request.form['country'].strip()
            contact_no = request.form['contact_no'].strip()
            dob_str = request.form['dob']
            account_type = request.form['account_type']
            
            # Validation
            if not name or len(name) < 2:
                flash('Name must be at least 2 characters long!', 'error')
                return render_template('update_account.html', customer=customer)
            
            if not email or '@' not in email:
                flash('Please enter a valid email address!', 'error')
                return render_template('update_account.html', customer=customer)
            
            if not contact_no or len(contact_no) < 10:
                flash('Contact number must be at least 10 digits!', 'error')
                return render_template('update_account.html', customer=customer)
            
            if not address or len(address) < 10:
                flash('Please enter a complete address!', 'error')
                return render_template('update_account.html', customer=customer)
            
            # Check if email is already used by another customer
            existing_customer = Customer.query.filter(
                Customer.email == email, 
                Customer.id != customer.id
            ).first()
            
            if existing_customer:
                flash('Email address is already registered with another account!', 'error')
                return render_template('update_account.html', customer=customer)
            
            # Convert date string to date object
            try:
                dob = datetime.strptime(dob_str, '%Y-%m-%d').date()
                
                # Age validation
                today = datetime.now().date()
                age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
                if age < 18:
                    flash('Customer must be at least 18 years old!', 'error')
                    return render_template('update_account.html', customer=customer)
                elif age > 100:
                    flash('Please enter a valid date of birth!', 'error')
                    return render_template('update_account.html', customer=customer)
                    
            except ValueError:
                flash('Invalid date format!', 'error')
                return render_template('update_account.html', customer=customer)
            
            # Update customer details
            customer.name = name
            customer.email = email
            customer.address = address
            customer.state = state
            customer.country = country
            customer.contact_no = contact_no
            customer.dob = dob
            customer.account_type = account_type
            customer.updated_at = datetime.utcnow()
            
            # Save changes
            db.session.commit()
            
            flash('Account details updated successfully!', 'success')
            return redirect(url_for('profile'))
            
        except Exception as e:
            db.session.rollback()
            flash('Failed to update account details. Please try again.', 'error')
            return render_template('update_account.html', customer=customer)
    
    return render_template('update_account.html', customer=customer)

@app.route('/change_password', methods=['GET', 'POST'])
def change_password():
    if 'user_id' not in session:
        flash('Please login to change your password.', 'error')
        return redirect(url_for('login'))
    
    customer = Customer.query.get(session['user_id'])
    if not customer:
        flash('Customer not found!', 'error')
        return redirect(url_for('logout'))
    
    if request.method == 'POST':
        current_password = request.form['current_password']
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']
        
        # Validate current password
        if not customer.check_password(current_password):
            flash('Current password is incorrect!', 'error')
            return render_template('change_password.html')
        
        # Validate new password
        if len(new_password) < 6:
            flash('New password must be at least 6 characters long!', 'error')
            return render_template('change_password.html')
        
        if new_password != confirm_password:
            flash('New passwords do not match!', 'error')
            return render_template('change_password.html')
        
        if current_password == new_password:
            flash('New password must be different from current password!', 'error')
            return render_template('change_password.html')
        
        try:
            # Update password
            customer.set_password(new_password)
            customer.updated_at = datetime.utcnow()
            db.session.commit()
            
            flash('Password changed successfully! Please login again for security.', 'success')
            return redirect(url_for('logout'))
            
        except Exception as e:
            db.session.rollback()
            flash('Failed to change password. Please try again.', 'error')
            return render_template('change_password.html')
    
    return render_template('change_password.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('login'))

# Create database tables
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
