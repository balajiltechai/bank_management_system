# Bank Management System

A comprehensive bank management system built with Python Flask that allows customers to register and login securely.

## Features

- Customer Registration with comprehensive details
- Secure Login/Logout functionality
- Password hashing for security
- Session management
- SQLite database for data storage

## Setup Instructions

1. Install required packages:
   ```
   pip install -r requirements.txt
   ```

2. Run the application:
   ```
   python app.py
   ```

3. Open your browser and navigate to `http://localhost:5000`

## Customer Registration Fields

- Name
- Username
- Password
- Address
- State
- Country
- Email Address
- PAN
- Contact Number
- Date of Birth
- Account Type

## Usage

1. Visit the registration page to create a new account
2. Fill in all required details
3. Login with your username and password
4. Use the logout feature to end your session
