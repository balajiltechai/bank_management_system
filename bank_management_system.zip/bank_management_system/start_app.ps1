# Start the Bank Management System
Set-Location "c:\Users\185385\OneDrive - Cognizant\Documents\Balaji\Github\bank_management_system"
Write-Host "Starting Bank Management System..." -ForegroundColor Green
Write-Host "The application will be available at http://localhost:5000" -ForegroundColor Yellow
.\.venv\Scripts\python.exe app.py
