"""
Manual test script for Account Update functionality
"""

import requests
import json

# Test configuration
BASE_URL = "http://127.0.0.1:5000"

def test_registration():
    """Test user registration"""
    print("Testing user registration...")
    
    data = {
        "name": "John Smith",
        "username": "johnsmith",
        "password": "password123",
        "confirm_password": "password123",
        "address": "123 Main Street, Apt 4B",
        "state": "New York",
        "country": "United States",
        "email": "john.smith@email.com",
        "pan": "ABCDE1234F",
        "contact_no": "555-123-4567",
        "dob": "1990-05-15",
        "account_type": "Savings"
    }
    
    try:
        response = requests.post(f"{BASE_URL}/register", data=data, allow_redirects=False)
        print(f"Registration response status: {response.status_code}")
        if response.status_code == 302:
            print("✓ Registration successful (redirected)")
            return True
        else:
            print(f"✗ Registration failed: {response.text}")
            return False
    except Exception as e:
        print(f"✗ Registration error: {e}")
        return False

def test_login():
    """Test user login"""
    print("Testing user login...")
    
    session = requests.Session()
    
    data = {
        "username": "johnsmith",
        "password": "password123"
    }
    
    try:
        response = session.post(f"{BASE_URL}/login", data=data, allow_redirects=False)
        print(f"Login response status: {response.status_code}")
        if response.status_code == 302:
            print("✓ Login successful (redirected)")
            return session
        else:
            print(f"✗ Login failed: {response.text}")
            return None
    except Exception as e:
        print(f"✗ Login error: {e}")
        return None

def test_update_account(session):
    """Test account update functionality"""
    print("Testing account update...")
    
    # First, get the update account page to see current data
    try:
        response = session.get(f"{BASE_URL}/update_account")
        print(f"Update account page status: {response.status_code}")
        
        if response.status_code != 200:
            print("✗ Could not access update account page")
            return False
            
        # Test update with new data
        updated_data = {
            "name": "John Updated Smith",
            "email": "john.updated.smith@email.com",
            "address": "123 Main Street, Apt 4B, Updated Address",
            "state": "New York",
            "country": "United States",
            "contact_no": "555-123-9999",
            "dob": "1990-05-15",
            "account_type": "Current"
        }
        
        response = session.post(f"{BASE_URL}/update_account", data=updated_data, allow_redirects=False)
        print(f"Update account response status: {response.status_code}")
        
        if response.status_code == 302:
            print("✓ Account update successful (redirected)")
            return True
        else:
            print(f"✗ Account update failed: {response.text}")
            return False
            
    except Exception as e:
        print(f"✗ Update account error: {e}")
        return False

def test_profile_view(session):
    """Test viewing updated profile"""
    print("Testing profile view...")
    
    try:
        response = session.get(f"{BASE_URL}/profile")
        print(f"Profile page status: {response.status_code}")
        
        if response.status_code == 200:
            # Check if updated data is visible
            if "John Updated Smith" in response.text:
                print("✓ Updated name visible in profile")
            if "john.updated.smith@email.com" in response.text:
                print("✓ Updated email visible in profile")
            if "Current" in response.text:
                print("✓ Updated account type visible in profile")
            print("✓ Profile view successful")
            return True
        else:
            print("✗ Could not view profile")
            return False
            
    except Exception as e:
        print(f"✗ Profile view error: {e}")
        return False

def main():
    """Run all tests"""
    print("=" * 60)
    print("Manual Test for Account Update Functionality")
    print("=" * 60)
    
    # Test registration
    if not test_registration():
        print("Stopping tests - registration failed")
        return
    
    # Test login
    session = test_login()
    if not session:
        print("Stopping tests - login failed")
        return
    
    # Test account update
    if not test_update_account(session):
        print("Account update test failed")
        return
    
    # Test profile view
    if not test_profile_view(session):
        print("Profile view test failed")
        return
    
    print("\n" + "=" * 60)
    print("✓ All Account Update Tests Passed!")
    print("=" * 60)
    print("\nFeatures tested:")
    print("✓ User registration")
    print("✓ User login")
    print("✓ Account details update")
    print("✓ Profile view with updated data")
    print("\nTo test manually:")
    print("1. Open http://127.0.0.1:5000")
    print("2. Login with username: johnsmith, password: password123")
    print("3. Navigate to Account -> Update Details")
    print("4. Modify any field and submit")
    print("5. Check the profile to see updated information")

if __name__ == "__main__":
    main()
