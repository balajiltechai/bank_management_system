# Bank Management System - Project Documentation

## Overview

A comprehensive web-based Bank Management System built with Python Flask that implements secure customer registration and login functionality. The system captures detailed customer information and provides a secure authentication mechanism with session management.

## Features Implemented

### ✅ Customer Registration
- **Complete Customer Information Capture:**
  - Name, Username, Password
  - Address, State, Country
  - Email Address, PAN Number
  - Contact Number, Date of Birth
  - Account Type selection

### ✅ Secure Login System
- **Authentication Features:**
  - Username and password validation
  - Secure password hashing using Werkzeug
  - Session management with automatic timeout
  - Account lockout after failed attempts (Enhanced version)
  - Password strength validation (Enhanced version)

### ✅ Loan Management System
- **Loan Application Features:**
  - Comprehensive loan application form
  - Multiple loan types (Personal, Home, Car, Business, Education, Gold)
  - Real-time EMI calculation and preview
  - Interest rate suggestions based on loan type
  - Loan amount validation (₹10,000 to ₹1,00,00,000)
  - Duration selection (6 months to 30 years)
  - Application date tracking

### ✅ Loan Tracking and Management
- **Loan Status Management:**
  - View all loan applications in organized table
  - Loan status tracking (Pending, Approved, Rejected)
  - Detailed loan information view
  - EMI schedule preview for approved loans
  - Loan summary statistics
  - Total approved amount and monthly EMI calculations

### ✅ Database Integration
- **SQLite Database with SQLAlchemy ORM:**
  - Customer data persistence
  - Loan application data storage
  - Secure password storage with hashing
  - Database relationships between customers and loans
  - Automatic table creation

### ✅ User Interface
- **Modern Bootstrap-based UI:**
  - Responsive design for all devices
  - Clean and professional appearance
  - Form validation and error handling
  - Flash messages for user feedback
  - Interactive EMI calculator
  - Loan management navigation

### ✅ Session Management
- **Secure Session Handling:**
  - Session invalidation on logout
  - Automatic redirection on session expiry
  - User authentication state management

## Project Structure

```
bank_management_system/
├── app.py                  # Main Flask application
├── app_enhanced.py         # Enhanced version with additional security
├── requirements.txt        # Python dependencies
├── README.md              # Project documentation
├── .env                   # Environment variables
├── start_app.bat          # Windows batch startup script
├── start_app.ps1          # PowerShell startup script
├── test_app.py            # Testing script
├── templates/             # HTML templates
│   ├── base.html          # Base template with navigation
│   ├── login.html         # Login page
│   ├── register.html      # Registration page
│   ├── dashboard.html     # Customer dashboard
│   ├── profile.html       # Customer profile view
│   └── error.html         # Error page template
└── .venv/                 # Virtual environment
```

## Acceptance Criteria Verification

### ✅ Customer Registration
- [x] Customer can register details in the system
- [x] Data is saved to SQLite database
- [x] All required fields are captured:
  - [x] Name, Username, Password
  - [x] Address, State, Country
  - [x] Email Address, PAN
  - [x] Contact No, DOB, Account Type

### ✅ Customer Login
- [x] Customer can login with User ID and Password
- [x] Credentials are validated against database
- [x] Session is created on successful login
- [x] Session is invalidated on logout
- [x] Login page is displayed after logout

### ✅ Loan Application (NEW)
- [x] Customer can apply for loans in the system
- [x] Loan data is saved to the database
- [x] All required loan fields are captured:
  - [x] Loan Type (Personal, Home, Car, Business, Education, Gold)
  - [x] Loan Amount (with validation)
  - [x] Application Date (auto-populated with today's date)
  - [x] Rate of Interest (with suggestions based on loan type)
  - [x] Duration of Loan (6 months to 30 years)

### ✅ Loan Management (NEW)
- [x] Customer can view all their loan applications
- [x] Loan details page with comprehensive information
- [x] EMI calculation and display
- [x] Loan status tracking (Pending, Approved, Rejected)
- [x] Dashboard integration with loan statistics

## Technical Implementation

### Backend Technologies
- **Python 3.13** - Programming language
- **Flask 2.3.3** - Web framework
- **SQLAlchemy 3.0.5** - ORM for database operations
- **SQLite** - Database for data storage
- **Werkzeug 2.3.7** - Password hashing and security utilities
- **python-dotenv 1.0.0** - Environment variable management

### Frontend Technologies
- **HTML5** - Markup language
- **Bootstrap 5.1.3** - CSS framework for responsive design
- **Font Awesome 6.0.0** - Icons and visual elements
- **JavaScript** - Client-side validation and interactions

### Security Features
- **Password Hashing** - Secure password storage using Werkzeug
- **Session Management** - Flask session handling with timeouts
- **Input Validation** - Server-side and client-side validation
- **CSRF Protection** - Built-in Flask CSRF protection
- **Account Lockout** - Protection against brute force attacks (Enhanced version)

## Installation and Setup

1. **Clone or extract the project:**
   ```bash
   cd bank_management_system
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the application:**
   ```bash
   python app.py
   ```

4. **Access the application:**
   - Open browser and navigate to `http://localhost:5000`

## Quick Start Scripts

### Windows Users:
- **Double-click `start_app.bat`** for command prompt execution
- **Run `start_app.ps1`** in PowerShell for enhanced startup

### Manual Execution:
```bash
# Navigate to project directory
cd bank_management_system

# Activate virtual environment (if using)
.venv\Scripts\activate

# Start the application
python app.py
```

## Testing

### Automated Testing
Run the included test script:
```bash
python test_app.py
```

### Manual Testing
1. **Registration Test:**
   - Go to `http://localhost:5000/register`
   - Fill in all required fields
   - Submit the form
   - Verify success message and redirection to login

2. **Login Test:**
   - Go to `http://localhost:5000/login`
   - Enter registered username and password
   - Verify successful login and dashboard access

3. **Session Test:**
   - Login successfully
   - Click logout
   - Verify redirection to login page
   - Try to access dashboard directly - should redirect to login

## Database Schema

### Customer Table
```sql
CREATE TABLE customer (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(100) NOT NULL,
    username VARCHAR(80) UNIQUE NOT NULL,
    password_hash VARCHAR(128) NOT NULL,
    address TEXT NOT NULL,
    state VARCHAR(50) NOT NULL,
    country VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    pan VARCHAR(10) UNIQUE NOT NULL,
    contact_no VARCHAR(15) NOT NULL,
    dob DATE NOT NULL,
    account_type VARCHAR(20) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### Loan Table (NEW)
```sql
CREATE TABLE loan (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    loan_type VARCHAR(50) NOT NULL,
    loan_amount FLOAT NOT NULL,
    application_date DATE NOT NULL,
    rate_of_interest FLOAT NOT NULL,
    duration_months INTEGER NOT NULL,
    status VARCHAR(20) DEFAULT 'Pending',
    monthly_emi FLOAT,
    customer_id INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customer (id)
);
```

## Enhanced Version Features

The `app_enhanced.py` includes additional security features:

- **Password Strength Validation** - Minimum 8 characters with uppercase, lowercase, and numbers
- **Account Lockout** - Automatic lockout after 5 failed login attempts
- **Session Timeout** - 30-minute automatic session expiration
- **Enhanced Validation** - Comprehensive input validation for all fields
- **Error Handling** - Custom error pages for 404 and 500 errors
- **Age Validation** - Minimum age requirement (18 years)
- **PAN Format Validation** - Strict PAN number format checking

## Future Enhancements

- Account balance management
- Transaction history
- Fund transfer functionality
- Account statements
- Password reset functionality
- Two-factor authentication
- Email verification
- Admin panel for account management
- **Loan Processing Workflow** (NEW)
  - Automated loan approval based on credit scores
  - Document upload for loan verification
  - Loan disbursement tracking
  - EMI payment tracking and reminders
  - Loan closure and prepayment options
- **Advanced Loan Features** (NEW)
  - Loan eligibility calculator
  - Credit score integration
  - Multiple guarantor support
  - Collateral management
  - Loan restructuring options

## Security Considerations

1. **Password Security:**
   - Passwords are hashed using Werkzeug's secure hashing
   - Original passwords are never stored in database

2. **Session Security:**
   - Sessions have automatic timeout
   - Session data is encrypted
   - Session invalidation on logout

3. **Input Validation:**
   - Server-side validation for all inputs
   - SQL injection prevention through ORM
   - XSS prevention through template escaping

4. **Account Protection:**
   - Account lockout mechanism
   - Failed login attempt tracking
   - Secure session management

## Support and Maintenance

- **Database:** SQLite file located in project root
- **Logs:** Flask development server logs
- **Configuration:** Environment variables in `.env` file
- **Backup:** Regular database backups recommended for production use

## Conclusion

This Bank Management System successfully implements all required features for customer registration and login functionality. The system provides a secure, user-friendly interface for customers to register their details and access their accounts through a robust authentication system.
