"""
Test script for Account Update functionality in Bank Management System
"""

import requests
import json
import time

# Configuration
BASE_URL = "http://localhost:5000"
TEST_USER_DATA = {
    "name": "Alice Johnson",
    "username": "alicejohnson",
    "password": "password123",
    "confirm_password": "password123",
    "address": "789 Pine Street, Apartment 5A",
    "state": "California",
    "country": "United States",
    "email": "alice.johnson@email.com",
    "pan": "KLMNO9876P",
    "contact_no": "+1-555-111-2222",
    "dob": "1992-12-15",
    "account_type": "Savings"
}

UPDATED_USER_DATA = {
    "name": "Alice Marie Johnson",
    "email": "alice.marie.johnson@email.com",
    "address": "789 Pine Street, Apartment 5A, Updated Building",
    "state": "California",
    "country": "United States",
    "contact_no": "+1-555-111-3333",
    "dob": "1992-12-15",
    "account_type": "Current"
}

PASSWORD_CHANGE_DATA = {
    "current_password": "password123",
    "new_password": "newpassword456",
    "confirm_password": "newpassword456"
}

def test_account_update_flow():
    """Test complete account update flow"""
    print("Testing account update flow...")
    
    session = requests.Session()
    
    try:
        # Step 1: Register a test user
        print("  1. Registering test user...")
        response = session.post(f"{BASE_URL}/register", data=TEST_USER_DATA)
        if response.status_code == 200:
            print("  ✓ User registration successful")
        else:
            print(f"  ✗ User registration failed: {response.status_code}")
            return False
        
        # Step 2: Login
        print("  2. Logging in...")
        login_data = {
            "username": TEST_USER_DATA["username"],
            "password": TEST_USER_DATA["password"]
        }
        response = session.post(f"{BASE_URL}/login", data=login_data)
        if response.status_code == 200 and "dashboard" in response.url.lower():
            print("  ✓ Login successful")
        else:
            print(f"  ✗ Login failed: {response.status_code}")
            return False
        
        # Step 3: Access update account page
        print("  3. Accessing update account page...")
        response = session.get(f"{BASE_URL}/update_account")
        if response.status_code == 200:
            print("  ✓ Update account page accessible")
            if TEST_USER_DATA["name"] in response.text:
                print("  ✓ Current user data is pre-populated")
            else:
                print("  ⚠ User data may not be pre-populated properly")
        else:
            print(f"  ✗ Cannot access update account page: {response.status_code}")
            return False
        
        # Step 4: Update account details
        print("  4. Updating account details...")
        response = session.post(f"{BASE_URL}/update_account", data=UPDATED_USER_DATA)
        if response.status_code == 200:
            print("  ✓ Account update submitted")
            if "successfully" in response.text.lower():
                print("  ✓ Account update appears successful")
            else:
                print("  ⚠ Account update may have issues")
        else:
            print(f"  ✗ Account update failed: {response.status_code}")
            return False
        
        # Step 5: Verify updates in profile
        print("  5. Verifying updates in profile...")
        response = session.get(f"{BASE_URL}/profile")
        if response.status_code == 200:
            if UPDATED_USER_DATA["name"] in response.text and UPDATED_USER_DATA["email"] in response.text:
                print("  ✓ Updated data appears in profile")
            else:
                print("  ⚠ Updated data may not be saved properly")
        else:
            print(f"  ✗ Cannot access profile page: {response.status_code}")
            return False
        
        print("  ✓ Account update flow test completed successfully!")
        return True
        
    except Exception as e:
        print(f"  ✗ Error in account update flow: {e}")
        return False

def test_password_change_flow():
    """Test password change functionality"""
    print("Testing password change flow...")
    
    session = requests.Session()
    
    try:
        # Login with updated credentials
        login_data = {
            "username": TEST_USER_DATA["username"],
            "password": TEST_USER_DATA["password"]
        }
        response = session.post(f"{BASE_URL}/login", data=login_data)
        
        if response.status_code == 200:
            print("  ✓ Logged in for password change test")
        else:
            print("  ✗ Cannot login for password change test")
            return False
        
        # Access change password page
        print("  1. Accessing change password page...")
        response = session.get(f"{BASE_URL}/change_password")
        if response.status_code == 200:
            print("  ✓ Change password page accessible")
        else:
            print(f"  ✗ Cannot access change password page: {response.status_code}")
            return False
        
        # Test password change
        print("  2. Changing password...")
        response = session.post(f"{BASE_URL}/change_password", data=PASSWORD_CHANGE_DATA)
        if response.status_code == 200:
            print("  ✓ Password change submitted")
            if "successfully" in response.text.lower() or "login" in response.url.lower():
                print("  ✓ Password change appears successful")
            else:
                print("  ⚠ Password change may have issues")
        else:
            print(f"  ✗ Password change failed: {response.status_code}")
            return False
        
        # Test login with new password
        print("  3. Testing login with new password...")
        new_session = requests.Session()
        new_login_data = {
            "username": TEST_USER_DATA["username"],
            "password": PASSWORD_CHANGE_DATA["new_password"]
        }
        response = new_session.post(f"{BASE_URL}/login", data=new_login_data)
        if response.status_code == 200 and "dashboard" in response.url.lower():
            print("  ✓ Login with new password successful")
        else:
            print("  ⚠ Login with new password may not be working")
        
        # Test that old password no longer works
        print("  4. Verifying old password is disabled...")
        old_session = requests.Session()
        old_login_data = {
            "username": TEST_USER_DATA["username"],
            "password": TEST_USER_DATA["password"]
        }
        response = old_session.post(f"{BASE_URL}/login", data=old_login_data)
        if "Invalid" in response.text or "dashboard" not in response.url.lower():
            print("  ✓ Old password correctly disabled")
        else:
            print("  ⚠ Old password may still be working")
        
        print("  ✓ Password change flow test completed!")
        return True
        
    except Exception as e:
        print(f"  ✗ Error in password change flow: {e}")
        return False

def test_account_update_validation():
    """Test account update validation"""
    print("Testing account update validation...")
    
    session = requests.Session()
    
    try:
        # Login first
        login_data = {
            "username": TEST_USER_DATA["username"],
            "password": PASSWORD_CHANGE_DATA["new_password"]  # Use new password
        }
        session.post(f"{BASE_URL}/login", data=login_data)
        
        # Test invalid email
        print("  1. Testing invalid email validation...")
        invalid_data = UPDATED_USER_DATA.copy()
        invalid_data["email"] = "invalid_email"
        
        response = session.post(f"{BASE_URL}/update_account", data=invalid_data)
        if "valid email" in response.text.lower():
            print("  ✓ Email validation working")
        else:
            print("  ⚠ Email validation may not be working")
        
        # Test empty name
        print("  2. Testing empty name validation...")
        invalid_data = UPDATED_USER_DATA.copy()
        invalid_data["name"] = ""
        
        response = session.post(f"{BASE_URL}/update_account", data=invalid_data)
        if "characters long" in response.text.lower():
            print("  ✓ Name validation working")
        else:
            print("  ⚠ Name validation may not be working")
        
        # Test invalid contact number
        print("  3. Testing contact number validation...")
        invalid_data = UPDATED_USER_DATA.copy()
        invalid_data["contact_no"] = "123"
        
        response = session.post(f"{BASE_URL}/update_account", data=invalid_data)
        if "10 digits" in response.text.lower():
            print("  ✓ Contact number validation working")
        else:
            print("  ⚠ Contact number validation may not be working")
        
        print("  ✓ Account update validation tests completed")
        
    except Exception as e:
        print(f"  ✗ Error in validation testing: {e}")

def test_account_pages_accessibility():
    """Test accessibility of account management pages"""
    print("Testing account management pages accessibility...")
    
    account_pages = [
        ("/update_account", "Update Account page"),
        ("/change_password", "Change Password page"),
    ]
    
    for path, description in account_pages:
        try:
            response = requests.get(f"{BASE_URL}{path}")
            # These pages require login, so 302 redirect is expected
            if response.status_code in [200, 302]:
                print(f"  ✓ {description} responding correctly")
            else:
                print(f"  ⚠ {description} returned status {response.status_code}")
        except Exception as e:
            print(f"  ✗ Error accessing {description}: {e}")

def main():
    """Main test function"""
    print("=" * 70)
    print("Bank Management System - Account Update Feature Test Suite")
    print("=" * 70)
    
    print("\nWaiting for application to start...")
    time.sleep(2)
    
    # Test basic application structure
    print("\n1. Testing basic application structure...")
    try:
        response = requests.get(BASE_URL)
        if response.status_code == 200:
            print("  ✓ Application is running")
        else:
            print(f"  ✗ Application not responding properly: {response.status_code}")
            return
    except requests.exceptions.ConnectionError:
        print("  ✗ Cannot connect to the application. Make sure it's running on localhost:5000")
        return
    
    # Test account pages accessibility
    print("\n2. Testing account management pages accessibility...")
    test_account_pages_accessibility()
    
    # Test complete account update flow
    print("\n3. Testing complete account update flow...")
    test_account_update_flow()
    
    # Test password change flow
    print("\n4. Testing password change flow...")
    test_password_change_flow()
    
    # Test validation
    print("\n5. Testing account update validation...")
    test_account_update_validation()
    
    print("\n" + "=" * 70)
    print("Account Update Feature Test Suite Completed!")
    print("=" * 70)
    print("\nAccount Management Features to Test Manually:")
    print("1. Open http://localhost:5000 and register/login")
    print("2. Navigate to 'Account' dropdown in navigation menu")
    print("3. Click 'Update Details' to modify account information")
    print("4. Test form validation with invalid inputs")
    print("5. Submit valid updates and verify changes in profile")
    print("6. Use 'Change Password' to update login credentials")
    print("7. Test password strength indicator and validation")
    print("8. Verify old password no longer works after change")
    print("9. Check that username and PAN cannot be modified")
    print("\nNew Features Implemented:")
    print("✓ Account details update form with validation")
    print("✓ Password change functionality with security")
    print("✓ Navigation menu integration")
    print("✓ Profile page enhancement with edit options")
    print("✓ Dashboard integration with account management")
    print("✓ Real-time form validation and feedback")
    print("✓ Security features (username/PAN protection)")
    print("✓ Password strength indicator")
    print("✓ Update timestamp tracking")

if __name__ == "__main__":
    main()
