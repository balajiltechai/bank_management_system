"""
Test script for Bank Management System
Run this to test the functionality of the application
"""

import requests
import json
import time

# Configuration
BASE_URL = "http://localhost:5000"
TEST_USER_DATA = {
    "name": "John Doe",
    "username": "johndoe",
    "password": "password123",
    "confirm_password": "password123",
    "address": "123 Main Street, Apartment 4B",
    "state": "California",
    "country": "United States",
    "email": "john.doe@email.com",
    "pan": "ABCDE1234F",
    "contact_no": "+1-555-123-4567",
    "dob": "1990-05-15",
    "account_type": "Savings"
}

def test_registration():
    """Test customer registration"""
    print("Testing customer registration...")
    
    try:
        response = requests.post(f"{BASE_URL}/register", data=TEST_USER_DATA)
        if response.status_code == 200:
            print("✓ Registration page accessible")
            if "Registration successful" in response.text or "Login" in response.text:
                print("✓ Registration appears to work")
            else:
                print("⚠ Registration may have issues")
        else:
            print(f"✗ Registration failed with status {response.status_code}")
    except requests.exceptions.ConnectionError:
        print("✗ Cannot connect to the application. Make sure it's running on localhost:5000")
        return False
    except Exception as e:
        print(f"✗ Error testing registration: {e}")
        return False
    
    return True

def test_login():
    """Test customer login"""
    print("Testing customer login...")
    
    try:
        # First, try to access login page
        response = requests.get(f"{BASE_URL}/login")
        if response.status_code == 200:
            print("✓ Login page accessible")
        else:
            print(f"✗ Login page failed with status {response.status_code}")
            return False
            
        # Test login functionality
        login_data = {
            "username": TEST_USER_DATA["username"],
            "password": TEST_USER_DATA["password"]
        }
        
        session = requests.Session()
        response = session.post(f"{BASE_URL}/login", data=login_data)
        if response.status_code == 200:
            print("✓ Login request processed")
            if "dashboard" in response.url.lower() or "Dashboard" in response.text:
                print("✓ Login appears successful")
            else:
                print("⚠ Login may have issues")
        else:
            print(f"✗ Login failed with status {response.status_code}")
            
    except Exception as e:
        print(f"✗ Error testing login: {e}")
        return False
    
    return True

def test_application_structure():
    """Test if all required pages are accessible"""
    print("Testing application structure...")
    
    pages = [
        ("/", "Homepage/Redirect"),
        ("/login", "Login page"),
        ("/register", "Registration page"),
    ]
    
    for path, description in pages:
        try:
            response = requests.get(f"{BASE_URL}{path}")
            if response.status_code == 200:
                print(f"✓ {description} accessible")
            else:
                print(f"⚠ {description} returned status {response.status_code}")
        except Exception as e:
            print(f"✗ Error accessing {description}: {e}")

def main():
    """Main test function"""
    print("=" * 50)
    print("Bank Management System - Test Suite")
    print("=" * 50)
    
    print("\nWaiting for application to start...")
    time.sleep(2)
    
    # Test application structure
    test_application_structure()
    print()
    
    # Test registration
    test_registration()
    print()
    
    # Test login
    test_login()
    print()
    
    print("=" * 50)
    print("Test completed!")
    print("=" * 50)
    print("\nTo manually test the application:")
    print("1. Open your browser and go to http://localhost:5000")
    print("2. Register a new customer account")
    print("3. Login with your credentials")
    print("4. Explore the dashboard and profile pages")
    print("5. Test the logout functionality")

if __name__ == "__main__":
    main()
