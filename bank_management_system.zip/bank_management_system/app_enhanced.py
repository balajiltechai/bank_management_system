"""
Enhanced Bank Management System with additional security features
"""

from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import os
import re
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev_secret_key_change_in_production')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///bank_management.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Session timeout (30 minutes)
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=30)

db = SQLAlchemy(app)

# Customer Model with enhanced validation
class Customer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    address = db.Column(db.Text, nullable=False)
    state = db.Column(db.String(50), nullable=False)
    country = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    pan = db.Column(db.String(10), unique=True, nullable=False)
    contact_no = db.Column(db.String(15), nullable=False)
    dob = db.Column(db.Date, nullable=False)
    account_type = db.Column(db.String(20), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    last_login = db.Column(db.DateTime)
    login_attempts = db.Column(db.Integer, default=0)
    locked_until = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def set_password(self, password):
        """Set password with hash"""
        if not self.validate_password(password):
            raise ValueError("Password does not meet security requirements")
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check password and handle login attempts"""
        if self.is_locked():
            return False
        
        if check_password_hash(self.password_hash, password):
            self.login_attempts = 0
            self.last_login = datetime.utcnow()
            self.locked_until = None
            db.session.commit()
            return True
        else:
            self.login_attempts += 1
            if self.login_attempts >= 5:  # Lock account after 5 failed attempts
                self.locked_until = datetime.utcnow() + timedelta(minutes=15)
            db.session.commit()
            return False
    
    def is_locked(self):
        """Check if account is locked"""
        if self.locked_until and datetime.utcnow() < self.locked_until:
            return True
        elif self.locked_until and datetime.utcnow() >= self.locked_until:
            # Unlock account if lock period has expired
            self.locked_until = None
            self.login_attempts = 0
            db.session.commit()
        return False
    
    @staticmethod
    def validate_password(password):
        """Validate password strength"""
        if len(password) < 8:
            return False
        if not re.search(r"[A-Z]", password):  # At least one uppercase
            return False
        if not re.search(r"[a-z]", password):  # At least one lowercase
            return False
        if not re.search(r"\d", password):     # At least one digit
            return False
        return True
    
    @staticmethod
    def validate_pan(pan):
        """Validate PAN format"""
        pattern = r'^[A-Z]{5}[0-9]{4}[A-Z]{1}$'
        return bool(re.match(pattern, pan))
    
    @staticmethod
    def validate_email(email):
        """Validate email format"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))
    
    def __repr__(self):
        return f'<Customer {self.username}>'

# Utility functions
def validate_registration_data(data):
    """Validate registration form data"""
    errors = []
    
    # Name validation
    if not data.get('name') or len(data['name'].strip()) < 2:
        errors.append("Name must be at least 2 characters long")
    
    # Username validation
    username = data.get('username', '').strip()
    if not username or len(username) < 3:
        errors.append("Username must be at least 3 characters long")
    elif not re.match(r'^[a-zA-Z0-9_]+$', username):
        errors.append("Username can only contain letters, numbers, and underscores")
    
    # Email validation
    if not Customer.validate_email(data.get('email', '')):
        errors.append("Invalid email format")
    
    # PAN validation
    if not Customer.validate_pan(data.get('pan', '').upper()):
        errors.append("Invalid PAN format (should be ABCDE1234F)")
    
    # Contact number validation
    contact = data.get('contact_no', '').strip()
    if not contact or len(contact) < 10:
        errors.append("Contact number must be at least 10 digits")
    
    # Date of birth validation
    try:
        dob = datetime.strptime(data.get('dob', ''), '%Y-%m-%d').date()
        today = datetime.now().date()
        age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
        if age < 18:
            errors.append("Customer must be at least 18 years old")
        elif age > 100:
            errors.append("Invalid date of birth")
    except ValueError:
        errors.append("Invalid date of birth format")
    
    # Password validation
    password = data.get('password', '')
    if not Customer.validate_password(password):
        errors.append("Password must be at least 8 characters with uppercase, lowercase, and number")
    
    if password != data.get('confirm_password', ''):
        errors.append("Passwords do not match")
    
    return errors

# Routes
@app.before_request
def before_request():
    """Set session as permanent and check for session timeout"""
    session.permanent = True
    
    # Skip authentication for static files and auth routes
    if request.endpoint in ['static', 'login', 'register', 'index']:
        return
    
    # Check if user is logged in
    if 'user_id' not in session:
        flash('Please login to access this page.', 'error')
        return redirect(url_for('login'))

@app.route('/')
def index():
    """Home page - redirect to dashboard if logged in, otherwise to login"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Customer registration with enhanced validation"""
    if request.method == 'POST':
        # Validate form data
        errors = validate_registration_data(request.form)
        
        if errors:
            for error in errors:
                flash(error, 'error')
            return render_template('register.html')
        
        # Check for existing records
        username = request.form['username'].strip()
        email = request.form['email'].strip().lower()
        pan = request.form['pan'].strip().upper()
        
        if Customer.query.filter_by(username=username).first():
            flash('Username already exists!', 'error')
            return render_template('register.html')
        
        if Customer.query.filter_by(email=email).first():
            flash('Email already registered!', 'error')
            return render_template('register.html')
        
        if Customer.query.filter_by(pan=pan).first():
            flash('PAN already registered!', 'error')
            return render_template('register.html')
        
        try:
            # Create new customer
            dob = datetime.strptime(request.form['dob'], '%Y-%m-%d').date()
            
            customer = Customer(
                name=request.form['name'].strip(),
                username=username,
                address=request.form['address'].strip(),
                state=request.form['state'].strip(),
                country=request.form['country'].strip(),
                email=email,
                pan=pan,
                contact_no=request.form['contact_no'].strip(),
                dob=dob,
                account_type=request.form['account_type']
            )
            customer.set_password(request.form['password'])
            
            db.session.add(customer)
            db.session.commit()
            
            flash('Registration successful! Please login with your credentials.', 'success')
            return redirect(url_for('login'))
            
        except ValueError as e:
            flash(str(e), 'error')
            return render_template('register.html')
        except Exception as e:
            db.session.rollback()
            flash('Registration failed! Please try again.', 'error')
            return render_template('register.html')
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Customer login with account locking"""
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        
        customer = Customer.query.filter_by(username=username).first()
        
        if not customer:
            flash('Invalid username or password!', 'error')
        elif not customer.is_active:
            flash('Your account has been deactivated. Please contact support.', 'error')
        elif customer.is_locked():
            flash('Account is temporarily locked due to multiple failed login attempts. Please try again later.', 'error')
        elif customer.check_password(password):
            session['user_id'] = customer.id
            session['username'] = customer.username
            session['login_time'] = datetime.utcnow().isoformat()
            flash(f'Welcome back, {customer.name}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            remaining_attempts = 5 - customer.login_attempts
            if remaining_attempts > 0:
                flash(f'Invalid username or password! {remaining_attempts} attempts remaining.', 'error')
            else:
                flash('Account locked due to multiple failed attempts. Please try again in 15 minutes.', 'error')
    
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    """Customer dashboard"""
    customer = Customer.query.get(session['user_id'])
    if not customer or not customer.is_active:
        flash('Account not found or inactive.', 'error')
        return redirect(url_for('logout'))
    
    return render_template('dashboard.html', customer=customer)

@app.route('/profile')
def profile():
    """Customer profile page"""
    customer = Customer.query.get(session['user_id'])
    if not customer or not customer.is_active:
        flash('Account not found or inactive.', 'error')
        return redirect(url_for('logout'))
    
    return render_template('profile.html', customer=customer)

@app.route('/logout')
def logout():
    """Logout and clear session"""
    username = session.get('username', 'User')
    session.clear()
    flash(f'Goodbye, {username}! You have been logged out successfully.', 'info')
    return redirect(url_for('login'))

# Error handlers
@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return render_template('error.html', 
                         error_code=404, 
                         error_message="Page not found"), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    db.session.rollback()
    return render_template('error.html', 
                         error_code=500, 
                         error_message="Internal server error"), 500

# Create database tables
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)
